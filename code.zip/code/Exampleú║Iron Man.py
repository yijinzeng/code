# -*- coding: utf-8 -*-
"""
Created on Tue May 28 22:01:00 2019

@author: Administrator
"""

"""
import sys
words=[]
with open('theavengers.txt','r') as f:
 for line in f:
 words.append(list(line.strip('\n').split(',')))
print(words)
"""
import sys
import igraph 
import numpy
import networkx as nx
import matplotlib.pyplot as plt
words=[]
with open('Iron man.txt','r') as f:
 for line in f:
     words.append(line)
decide = 0     
central = []   
name = []         
imname = []       

for word in name:            
    if (word not in imname):
        imname.append(word)
print(imname)
counts = {}
for word in name:
    counts[word] = counts.get(word,0)+1
items = list(counts.items())
items.sort(key = lambda x:x[1],reverse = True)
for i in range(len(imname)): 
    word,count = items[i]
relationship= np.zeros((len(imname),len(imname)),np.uint16)
for i in range(len(name)-4):
    if (name[i] == name[i+2])&(name[i+1] == name[i+3]):
        relationship[imname.index(name[i])][imname.index(name[i+1])] = relationship[imname.index(name[i])][imname.index(name[i+1])]+1
        i = i+4
central= np.zeros((len(imname)),np.uint16)
for i in range(len(imname)):           
    central[i] = sum(relationship[i])
relationship = np.transpose(relationship)  
for i in range(len(imname)):           
    central[i] = central[i]+sum(relationship[i])
relationship = np.transpose(relationship)
numpy.savetxt("new.csv",relationship,delimiter=',')         
G = nx.Graph()   
for i in range(len(relationship)):
    for j in range(len(relationship)):
        if(relationship[i][j]!=0):
            G.add_edge(i, j)   
nx.draw(G)
plt.show()
g = igraph.Graph()
vertex=[]
for word in imname:
    vertex.append(word)
g.add_vertices(vertex)
edges = []
for i in range(len(relationship)):
    for j in range(len(relationship)):
        if(relationship[i][j]!=0):
            edges.append((imname[i],imname[j]))
g.add_edges(edges)
numbers = g.degree()
neighbors = dict(zip(vertex, numbers))
print(' $$各点的度 $$' ,neighbors)
betweenness = g.betweenness()
betweenness = [round(i, 1) for i in betweenness]
country_betweenness = dict(zip(vertex, betweenness))
print(' $$中介中心性 $$ ', country_betweenness)  
numbers.sort()       
plt.bar(range(len(numbers)),numbers,color='rgb',tick_label=imname)
plt.show()
print('最大深度：',max(numbers))
betweenness.sort()
plt.bar(range(len(betweenness)),betweenness,color='rgb',tick_label=imname)
plt.show()
print('最大中介中心性：',max(betweenness))
print('角色数:',g.vcount())
print('cluster:4')
print('MAXcluster:19')
print(g.clusters())
print('直径:',g.diameter())
names = g.vs["name"]
print(g.get_diameter())
print([names[x] for x in g.get_diameter()])     
ecount = g.ecount()
print('边的数目：',ecount)
vcount = g.vcount()
print('节点数目：',vcount)
counts2 = 0;
for i in range(0,len(numbers)):
    if(numbers[i] == 0):
        counts2 = counts2 + 1;
print("度为零的角色数",counts2)
counts3 = 0;
for i in range(0,len(betweenness)):
    if(numbers[i] == 0):
        counts3 = counts3 + 1;
print("中介中心性为零的角色数",counts3)
print("最大",max(g.get_diameter()))
print("最小",min(g.get_diameter()))
print(max(g.closeness()))
print(min(g.closeness()))
imname1 = imname;
counts1 = 0;
for i in range(len(relationship)):
    for j in range(len(relationship)):
        if(relationship[i][j]!=0):
            imname1[i] = 1;
            imname1[j] = 1;
for i in range(0,len(imname1)):
    if(imname1[i] == 1):
        counts1 = counts1+1;
print("有两次连续对话的角色数目",counts1)
help(g.get_diameter)
help(g.diameter)